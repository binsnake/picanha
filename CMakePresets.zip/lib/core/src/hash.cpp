#include "picanha/core/hash.hpp"

// Hash implementation is entirely in the header (inline)
// This file exists to ensure the header compiles correctly.

namespace picanha {

// Placeholder for any future non-inline implementations

} // namespace picanha
