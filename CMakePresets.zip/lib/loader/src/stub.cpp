// Placeholder for Stage 2 implementation
namespace picanha::loader {
    // PE/COFF loader will be implemented in Stage 2
}
