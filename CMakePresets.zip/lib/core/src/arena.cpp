#include "picanha/core/arena.hpp"

// Arena implementation is entirely in the header (inline/template)
// This file exists for potential future non-inline implementations
// and to ensure the header compiles correctly.

namespace picanha {

// Placeholder for any future non-template implementations

} // namespace picanha
